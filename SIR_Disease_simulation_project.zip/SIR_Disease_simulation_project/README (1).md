# SIR_Disease_Simulation_Project
R-based simulation of the SIR (Susceptible-Infected-Recovered) model using deSolve and ggplot2, demonstrating disease transmission over time.
